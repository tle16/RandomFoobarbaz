#include "swap.h"

struct foobarbaz *rand_foobarbaz() {
    struct foobarbaz *rand_range;
    int i = 0;

    rand_range = malloc (sizeof(struct foobarbaz) * 20); /*creates array of 20*/

    for(i = 0; i < 20; i++) {/*assigns random numbers to the array*/
        rand_range[i].foo = rand_double(0,50);
        rand_range[i].bar = rand_double(0,101);
        rand_range[i].baz = rand_double(51,100);
    }

    return rand_range;
}
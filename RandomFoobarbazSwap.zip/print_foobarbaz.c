#include "swap.h"

void print_foobarbaz(struct foobarbaz *foobarbaz_many) {
    int i = 0;

    for(i = 0; i < 20; i++) {/*prints in columns*/
            printf("%d\t%0.1f\t%d\n", foobarbaz_many[i].foo, foobarbaz_many[i].bar, foobarbaz_many[i].baz);
    }

    printf("\n");
}
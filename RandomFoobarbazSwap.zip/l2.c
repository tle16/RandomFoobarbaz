#include "swap.h"

int main() {
    
    struct foobarbaz *foobarbaz_many = NULL;
    struct foobarbaz *foobarbaz_swap = NULL;    
    int x = rand() % 20;
    int y = rand() % 20;

    foobarbaz_many = many_foobarbaz();/*creates the structure array*/
    print_foobarbaz(foobarbaz_many);
    foobarbaz_swap = swap_foobarbaz(foobarbaz_many, x, y);/*randomly swaps locations of the structure*/
    print_foobarbaz(foobarbaz_swap);

    free(foobarbaz_many);
    free(foobarbaz_swap);

    return 0;
}
#include "swap.h"

double rand_double(double a, double b) {
    double holder = 0;
    double random_num;

    if (b < a) {
        holder = b;
        b = a;
        a = holder;

        random_num = ((double) rand() / (double) RAND_MAX)* (b - a)+ a;
    }
    else {
        random_num = ((double) rand() / (double) RAND_MAX)* (b - a) + a;
    }
    return random_num;
}
#include "swap.h"

struct foobarbaz *many_foobarbaz() {
    struct foobarbaz *many;

    many = rand_foobarbaz(); /*calls the function that will create the random numbers in the array*/
    
    return many;
}
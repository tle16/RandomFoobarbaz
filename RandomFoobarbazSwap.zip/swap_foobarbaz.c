#include "swap.h"

struct foobarbaz *swap_foobarbaz(struct foobarbaz *many_foobarbaz, int x, int y) {
    struct foobarbaz *swap;
    int i = 0;

    swap = malloc(sizeof(struct foobarbaz) * 20);
    for(i = 0; i < 20; i++) {
        swap[i] = many_foobarbaz[i];
    }
    swap[x] = many_foobarbaz[y];/*swap*/
    swap[y] = many_foobarbaz[x];

    printf("Swapping position %d with %d\n\n", x, y);

    return swap;
}
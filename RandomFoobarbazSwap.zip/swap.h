#ifndef WORDSORT_H
#define  WORDSORT_H
#include <stdio.h>
#include <stdlib.h>

/*Structures*/
struct foobarbaz {
    int foo;
    double bar;
    int baz;
};

/*Functions*/
double rand_double(double a, double b);
struct foobarbaz *many_foobarbaz();
void print_foobarbaz(struct foobarbaz *foobarbaz_many);
struct foobarbaz *swap_foobarbaz(struct foobarbaz *many_foobarbaz, int x, int y);
struct foobarbaz *rand_foobarbaz();

#endif